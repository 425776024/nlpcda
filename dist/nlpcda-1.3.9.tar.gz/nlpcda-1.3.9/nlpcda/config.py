#!/usr/bin/python
# -*- coding: utf-8 -*-

import os

root_path = os.path.abspath(os.path.dirname(__file__))

homophone_path = root_path + '/data/同音意字.txt'
similarword_path = root_path + '/data/同义词.txt'

random_path = root_path + '/data/company.txt'
company_path = root_path + '/data/company.txt'

quick_start_path = root_path + '/data/quick_start.txt'
