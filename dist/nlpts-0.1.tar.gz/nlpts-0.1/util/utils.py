#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2019/12/29 12:41 PM
# @Author  : xinfa.jiang
# @Site    : 
# @File    : utils.py
# @Software: PyCharm

def test_one():
    print('nlp ts')
